package Function_Lib;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;


public class InitAndDestroy {

	public static WebDriver driver = null;
	static Logger app_logs= Logger.getLogger(InitAndDestroy.class);
	
	@BeforeSuite
	public void beforesuit() throws Exception
	{		
		app_logs.info("========================================");
		app_logs.info("Test Suite Started ::");
		app_logs.info("========================================");
	}	
	
	@BeforeTest
	
	public static void beforeClass() throws Throwable{

		try{
			PropertyConfigurator.configure("src/main/resources/log4j.properties");
			app_logs.info("*********** START OF SUITE**************");

			app_logs.info("*********** start of SUITE PARAMETRES**************");

			
		
		}catch(Exception e){

			e.printStackTrace();
			Assert.fail();

		}
		
	}
	
	@AfterTest	
	public void aftertest() throws Exception
	{	
		
		app_logs.info("========================================");
		app_logs.info("Test Completed ::");
		app_logs.info("========================================");				
	}

	@AfterSuite
	public void aftersuit() throws Exception
	{
	
		app_logs.info("========================================");
		app_logs.info("Test Suite Completed ::");
		app_logs.info("========================================");
		
		
			
	}

	
	
}
