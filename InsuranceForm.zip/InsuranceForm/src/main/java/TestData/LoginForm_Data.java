package TestData;

public class LoginForm_Data {
	
	public static String email="john.smith@gmail.com";
	public static String password="john";
	public static String expectedUser="John Smith";
	
}
