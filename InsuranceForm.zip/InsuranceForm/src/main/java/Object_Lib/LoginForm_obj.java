package Object_Lib;

import org.openqa.selenium.By;

public class LoginForm_obj {
	public static By by= null;


	public static By login_email(){

		by= By.xpath("//input[@id='login-form:email']");

		return by;
	}
	public static By login_password(){

		by= By.xpath("//input[@id='login-form:password']");

		return by;
	}
	public static By login_button(){

		by= By.xpath("//input[@id='login-form:login']");

		return by;
	}
	public static By login_label(){

		by= By.xpath("//label[@class='login']");

		return by;
	}
}
