package TestScripts;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Object_Lib.LoginForm_obj;
import TestData.LoginForm_Data;

public class LoginForm {
	public WebDriver driver;
	final static Logger APP_LOGS = Logger.getLogger(new Throwable().getStackTrace()[0].getClassName());
	@Test
	public void login() throws Exception
	{

		try{
			APP_LOGS.info("Start of the Automation");
			System.setProperty("webdriver.gecko.driver","Executables/GeckoDriver/geckodriver.exe");
			driver=new FirefoxDriver();
			Thread.sleep(5000);
			APP_LOGS.info("Browser Launched Successfully");
			String url = "http://demo.borland.com/InsuranceWebExtJS/index.jsf";
			driver.get(url);
			
			//------------------Login Page Start--------------------------
			driver.findElement(LoginForm_obj.login_email()).sendKeys(LoginForm_Data.email);
			driver.findElement(LoginForm_obj.login_password()).sendKeys(LoginForm_Data.password);
			driver.findElement(LoginForm_obj.login_button()).click();
			APP_LOGS.info("Login Successfully");
			WebElement name= driver.findElement(LoginForm_obj.login_label());
			//Assertion
			Assert.assertEquals(LoginForm_Data.expectedUser,name.getText());
			APP_LOGS.info("The expected user is signed in");
			//--------------------Login Complete---------------------------

			//------------------Auto Quote Start---------------------------
			Select action=new Select(driver.findElement(By.xpath("//select[@id='quick-link:jump-menu']")));
			action.selectByVisibleText("Auto Quote");
			APP_LOGS.info("Start of the Auto Quote Flow");
			
			//---------Implicit wait----------
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

			driver.findElement(By.xpath("//input[@id='autoquote:zipcode']")).sendKeys("1234");
			driver.findElement(By.xpath("//input[@id='autoquote:e-mail']")).sendKeys("abc@gmail.com");
			driver.findElement(By.xpath("//input[@value='truck']")).click();
			driver.findElement(By.xpath("//input[@id='autoquote:next']")).click();
			
			WebElement age =driver.findElement(By.xpath("//input[@id='autoquote:age']"));
			age.clear();
			age.sendKeys("25");
			driver.findElement(By.xpath("//input[@value='Male']")).click();
			driver.findElement(By.xpath("//input[@value='Excellent']")).click();
			driver.findElement(By.xpath("//input[@id='autoquote:next']")).click();
			
			WebElement year=driver.findElement(By.xpath("//input[@id='autoquote:year']"));
			year.clear();
			year.sendKeys("2017");
			Thread.sleep(5000);
			WebElement make=driver.findElement(By.xpath("//input[@id='makeCombo']"));
			make.click();
			make.sendKeys("Toyota");
			Thread.sleep(4000);
			driver.findElement(By.xpath("//div[contains(text(),'Toyota')]")).click();

			WebElement model=driver.findElement(By.xpath("//input[@id='modelCombo']"));
			model.click();
			model.sendKeys("Avalon");
			Thread.sleep(4000);
			driver.findElement(By.xpath("//div[contains(text(),'Avalon')]")).click();

			driver.findElement(By.xpath("//input[@value='Own']")).click();
			driver.findElement(By.xpath("//input[@id='autoquote:next']")).click();
			//-----------------------Auto Quote Complete-------------------
			
			String zipC=driver.findElement(By.xpath("//span[@id='quote-result:zipcode']")).getText();
			System.out.println("text--"+zipC);
			//------------As below other fields can also be compared----------
			if (zipC.equalsIgnoreCase("1234"))
			{
				APP_LOGS.info("Correct Zipcode");
			}
			else
			{
				APP_LOGS.info("InCorrect Zipcode");
			}
			
			//------------------Purchase Started---------------------------
			driver.findElement(By.xpath("//input[@id='quote-result:purchase-quote']")).click();
			APP_LOGS.info("User Choose to purchase");
			//Purchase Screen
			driver.findElement(By.xpath("//input[@id='purchaseQuote:cardnumber']")).sendKeys("1294 4863 2356 3975");
			driver.findElement(By.xpath("//input[@id='purchaseQuote:expiration']")).sendKeys("02/27");
			driver.findElement(By.xpath("//input[@id='purchaseQuote:purchase']")).click();	
			String c=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[4]/h1[1]")).getText();
			System.out.println(c+"The text");
			
			if(c.equalsIgnoreCase("Congratulations!"))
			{
				APP_LOGS.info("Successful purchase");
			}
			else
			{
				APP_LOGS.info("Issue with Purchase");
			}
			//--------------------Logout-----------------
			
			//-----------Explicit Wait--------------------
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@id='home']//a[contains(text(),'Home')]")));
			driver.findElement(By.xpath("//li[@id='home']//a[contains(text(),'Home')]")).click();
			driver.findElement(By.xpath("//input[@id='logout-form:logout']")).click();
			APP_LOGS.info("Logged Out Successfully");
		}

		catch (Exception e) {
			e.printStackTrace();
			APP_LOGS.info("Failed in Login Form bcz-->" + e.getMessage());
			Assert.fail();
			throw new Exception(e.getMessage());
		}
		finally{
			driver.close();
			APP_LOGS.info("End of Session");
		}
	}

}


