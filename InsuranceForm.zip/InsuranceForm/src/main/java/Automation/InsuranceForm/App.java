package Automation.InsuranceForm;


public class App {
	
	public static void main() throws Exception
	{
		System.out.println("Hello");
	} 
	
	}


